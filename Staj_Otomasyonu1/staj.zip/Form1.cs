﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static string conString = "Data Source=DESKTOP-33JLNQJ\\SQLEXPRESS;Database=$safeprojectname$; Integrated Security=True;Connect Timeout=30;Encrypt=True;TrustServerCertificate=True;";
        SqlConnection Connect = new SqlConnection(conString);
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (Connect.State == ConnectionState.Closed)
                    Connect.Open();
                string $safeprojectname$ = "insert into Bilgi (adi,soyadi,tc,telefon,yuksekokuladi,programi,okulturu,baslamabitistarihi,memurmu,sigortalimi,kurumadi,kurumadresi,kurumtel,calismalani) values(@adi,@soyadi,@tc,@telefon,@yuksekokuladi,@programi,@okulturu,@baslamabitistarihi,@memurmu,@sigortalimi,@kurumadi,@kurumadresi,@kurumtel,@calismalani)";
                SqlCommand komut = new SqlCommand($safeprojectname$, Connect);
                komut.Parameters.AddWithValue("@adi", textBox1.Text);
                komut.Parameters.AddWithValue("@soyadi", textBox2.Text);
                komut.Parameters.AddWithValue("@tc", textBox3.Text);
                komut.Parameters.AddWithValue("@telefon", textBox4.Text);
                komut.Parameters.AddWithValue("@yuksekokuladi", textBox5.Text);
                komut.Parameters.AddWithValue("@programi", textBox6.Text);
                komut.Parameters.AddWithValue("@okulturu", textBox7.Text);
                komut.Parameters.AddWithValue("@baslamabitistarihi", textBox8.Text);
                komut.Parameters.AddWithValue("@memurmu", textBox9.Text);
                komut.Parameters.AddWithValue("@sigortalimi", textBox10.Text);
                komut.Parameters.AddWithValue("@kurumadi", textBox11.Text);
                komut.Parameters.AddWithValue("@kurumadresi", textBox12.Text);
                komut.Parameters.AddWithValue("@kurumtel", textBox13.Text);
                komut.Parameters.AddWithValue("@calismalani", textBox14.Text);
                komut.ExecuteNonQuery();
                Connect.Close();
                MessageBox.Show("Kaydedildi.");


            }
            catch(Exception hata)
            {
                MessageBox.Show("Hata!" + hata.Message);
            }
        }
    }
}
